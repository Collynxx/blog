import React from 'react'

const Card = () => {
  return (
    <div className='resultCard'>
      <figure className=''>
        <img src='' alt=''/>
      </figure>
      <h4>News Title</h4>
      <span>Date</span>
    </div>
  )
}

export default Card
