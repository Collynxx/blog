export const blogList = [
  {
    id: 1,
    title:
      "Risus pulvinar placerat eget cras mattis cursus. Odio pretium malesuada aliquet habitasse. Fusce vitae, risus vulputate ut libero nascetur blandit quam potenti.",
    category: "news",
    description:
      "Non senectus odio ut ac nulla vestibulum. Bibendum risus ac ut ullamcorper. Vitae, lectus phasellus tristique mauris id eget. Lorem lorem dignissim est sit libero. Quis commodo accumsan nam eros, pellentesque posuere. Pulvinar in consequat ultrices sed cursus. Cras neque, egestas sodales quis interdum sed. In auctor amet, metus egestas. Condimentum ut congue ac in facilisi at sem dolor. Mauris neque fames vulputate amet, dignissim vulputate. Ridiculus vitae, purus nisi, placerat cras tristique. Aliquam ac suscipit sed tincidunt. Rhoncus eu etiam mattis egestas accumsan nunc orci. Ut laoreet bibendum sed sed adipiscing tortor. Suspendisse quisque massa consectetur nulla tempus sit hac nisi, diam. Accumsan ultrices dui tristique arcu. At blandit egestas aliquet eu at ut aliquet viverra. Sed est at dignissim lacus, tristique. Id consequat semper cras faucibus. Lobortis erat diam tortor diam tempor auctor. Eu ipsum integer viverra feugiat cras. Senectus ultrices tempus, adipiscing sem sed dignissim. Sit consequat sem mauris, dis lorem euismod morbi. Turpis ac nunc nunc odio quisque mi augue sagittis. Euismod adipiscing gravida imperdiet convallis eget. Mauris, a, in sed diam molestie commodo. Sit vitae tristique laoreet enim faucibus quam tellus massa. Lacus urna nunc, nibh odio. Quis dui vel iaculis nunc ultricies. Fermentum proin nisl nisi eleifend ultricies sagittis amet, amet pretium. Fringilla sit congue vestibulum faucibus integer tempus. Leo diam enim morbi pellentesque facilisis ante ipsum nibh laoreet. Ipsum mi aliquam bibendum vulputate eget. Nisl, in quam hendrerit arcu ipsum sodales donec. Sollicitudin cursus metus justo, quisque. Mi, vel ut sit dignissim ultrices. Sem potenti integer sem et. Sed suspendisse elit, dictum odio et mi facilisis est. Ac non, pellentesque lacus vestibulum. Laoreet aliquet nunc vel facilisi laoreet. Semper eget morbi pellentesque id pellentesque id. Ipsum neque leo amet ultrices. Massa convallis egestas morbi eget tellus non sit. Blandit eu eu nunc dolor tellus pharetra. Vel nec nec neque, elementum. Amet dolor quam tellus, id pellentesque interdum sit pretium. Volutpat malesuada volutpat sapien parturient faucibus. Sed massa massa eleifend est facilisi erat quam ullamcorper erat. Aenean viverra ultrices mattis massa in. Nunc sit suspendisse velit vel fermentum, aenean consequat. Aenean elit sollicitudin est bibendum neque leo, sapien purus turpis. Egestas dictumst lorem quis semper leo risus. In accumsan duis feugiat integer ornare nec, praesent viverra.",
    createdAt: "July 19, 2022",
    cover: "../assets/images/chineseflag.png",
  },
  {
    id: 2,
    title:
      "Senectus tincidunt luctus placerat ac nibh facilisi mi. Id dolor in mauris, pharetra, commodo. Dui et morbi a tortor condimentum nulla at ullamcorper male.",
    category: "news",
    description:
      "Sed sit risus purus a augue eget consequat sit purus. Eget sed vitae diam hac quisque urna, nullam tristique erat. Molestie amet. Lorem lorem dignissim est sit libero. Quis commodo accumsan nam eros, pellentesque posuere. Pulvinar in consequat ultrices sed cursus. Cras neque, egestas sodales quis interdum sed. In auctor amet, metus egestas. Condimentum ut congue ac in facilisi at sem dolor. Mauris neque fames vulputate amet, dignissim vulputate. Ridiculus vitae, purus nisi, placerat cras tristique. Aliquam ac suscipit sed tincidunt. Rhoncus eu etiam mattis egestas accumsan nunc orci. Ut laoreet bibendum sed sed adipiscing tortor. Suspendisse quisque massa consectetur nulla tempus sit hac nisi, diam. Accumsan ultrices dui tristique arcu. At blandit egestas aliquet eu at ut aliquet viverra. Sed est at dignissim lacus, tristique. Id consequat semper cras faucibus. Lobortis erat diam tortor diam tempor auctor. Eu ipsum integer viverra feugiat cras. Senectus ultrices tempus, adipiscing sem sed dignissim. Sit consequat sem mauris, dis lorem euismod morbi. Turpis ac nunc nunc odio quisque mi augue sagittis. Euismod adipiscing gravida imperdiet convallis eget. Mauris, a, in sed diam molestie commodo. Sit vitae tristique laoreet enim faucibus quam tellus massa. Lacus urna nunc, nibh odio. Quis dui vel iaculis nunc ultricies. Fermentum proin nisl nisi eleifend ultricies sagittis amet, amet pretium. Fringilla sit congue vestibulum",
    createdAt: "Mar 9, 2022",
    cover: "../assets/images/bman.png",
  },
  {
    id: 3,
    title:
      "Quam porta aenean sapien a vestibulum orci gravida. Sit tristique dolor tortor lectus natoque vitae fermentum pellentesque. Auctor suspendisse pellentesque est nec.",
    category: "politics",
    description:
      "Non senectus odio ut ac nulla vestibulum. Bibendum risus ac ut ullamcorper. Vitae, lectus phasellus tristique mauris id eget. Nisl enim pellentesque diam tincidunt eu eget congue leo eget. Et tempor arcu risus sem gravida elit ut sollicitudin integer. Nisl enim pellentesque diam tincidunt eu eget congue leo eget. Et tempor arcu risus sem gravida elit ut sollicitudin integer. Lorem lorem dignissim est sit libero. Quis commodo accumsan nam eros, pellentesque posuere. Pulvinar in consequat ultrices sed cursus. Cras neque, egestas sodales quis interdum sed. In auctor amet, metus egestas. Condimentum ut congue ac in facilisi at sem dolor. Mauris neque fames vulputate amet, dignissim vulputate. Ridiculus vitae, purus nisi, placerat cras tristique. Aliquam ac suscipit sed tincidunt. Rhoncus eu etiam mattis egestas accumsan nunc orci. Ut laoreet bibendum sed sed adipiscing tortor. Suspendisse quisque massa consectetur nulla tempus sit hac nisi, diam. Accumsan ultrices dui tristique arcu. At blandit egestas aliquet eu at ut aliquet viverra. Sed est at dignissim lacus, tristique. Id consequat semper cras faucibus. Lobortis erat diam tortor diam tempor auctor. Eu ipsum integer viverra feugiat cras. Senectus ultrices tempus, adipiscing sem sed dignissim. Sit consequat sem mauris, dis lorem euismod morbi. Turpis ac nunc nunc odio quisque mi augue sagittis. Euismod adipiscing gravida imperdiet convallis eget. Mauris, a, in sed diam molestie commodo. Sit vitae tristique laoreet enim faucibus quam tellus massa. Lacus urna nunc, nibh odio. Quis dui vel iaculis nunc ultricies. Fermentum proin nisl nisi eleifend ultricies sagittis amet, amet pretium. Fringilla sit congue vestibulum",
    createdAt: "Mar 2, 2022",
    cover: "../assets/images/flag.png",
  },
  {
    id: 4,
    title:
      "Imperdiet pretium lectus at tincidunt pellentesque. Velit tristique id magna semper lacus elementum arcu diam urna. Turpis dolor mauris pretium augue euismo.",
    category: "entertainment",
    description:
      "Eget rhoncus viverra aliquet porta in nisl. Elit bibendum elit eu dictum metus vitae, dolor id. Ipsum duis leo ipsum nam. ",
    createdAt: "jun 2, 2022",
    cover: "../assets/images/reporter.png",
  },
  {
    id: 5,
    title:
      "Blandit eget at turpis elit non etiam eget. Ridiculus pulvinar scelerisque cum nunc fames nisl. Aliquam etiam blandit placerat amet posuere urna, erat. Mauris est hen.",
    category: "sports",
    description:
      "Eu orci erat ac amet, elementum. Porttitor ultrices lorem velit non risus. Dignissim diam fringilla eu penatibus elementumt.",
    createdAt: "Jun 4, 2020",
    cover: "../assets/images/sonia.png",
  },
  {
    id: 6,
    title:
      "Urna vitae, tempor, morbi commodo sit nisi. Eu egestas platea porttitor in malesuada pulvinar. Maecenas vel pellentesque ultrices eu lectus varius plate.",
    category: "education",
    description:
      "Nisl enim pellentesque diam tincidunt eu eget congue leo eget. Et tempor arcu risus sem gravida elit ut sollicitudin integer. Morbi",
    createdAt: "july 14, 2022",
    cover: "../assets/images/elaine.png",
  },
];
export const relatedList = [
  {
    id: 1,
    title:
      "Ornare hendrerit viverra eleifend nunc suspendisse tristique sem proin. Suspendisse et, faucibus aenean tellus accumsan ullamcorper in in dignissim. ",
    category: "news",
    description:
      "In eget nulla augue mauris, faucibus tellus adipiscing platea vel. Sed sed erat at integer habitasse eros, neque scelerisque. ",
    createdAt: "July 19, 2022",
    cover: "../assets/images/people.png",
  },
  {
    id: 2,
    title:
      "Duis orci elementum nam mattis ultrices feugiat non nisi, sed. Diam tincidunt ut in habitasse ultricies sed elit, placerat dignissim. Aliquet tempus turpis sagittis.",
    category: "news",
    description:
      "Dolor, ut donec aliquam mauris gravida ut. Vivamus purus etiam orci egestas ipsum enim pellentesque risus leo.",
    createdAt: "July 19, 2022",
    cover: "../assets/images/red.png",
  },
  {
    id: 3,
    title:
      "Facilisis duis donec turpis ac eget turpis consequat. Eu quam lorem eget viverra risus ipsum facilisis. Vestibulum, faucibus habitasse gravida viverra mattis.",
    category: "news",
    description:
      "Id malesuada sed feugiat morbi elit ac nulla in morbi. Nunc lacus, mi, tortor dui. In nullam nec ante aliquam magna sapien.",
    createdAt: "July 19, 2022",
    cover: "../assets/images/dman.png",
  },
];
