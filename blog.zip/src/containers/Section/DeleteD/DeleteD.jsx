import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "../section.css";

const DeleteD = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="posts">
          <div className="half2">
            <div className="card ">
              <div className="card-body">
                <div className="media align-items-stretch">
                  <div className="media-body">
                    <h4>Posts</h4>
                    <h3>3</h3>
                  </div>
                  <div className="align-self-center">D</div>
                </div>
              </div>
            </div>
            <br />
            {/* posts */}
            <div className="border p-3">
              <p className="title">
                Hello i am here to test the headimg amd alsop show collins i am
                not good in front end
              </p>
              <p className="grey">Published: 18 may</p>
              <div className="dflex justify-content-between">
                <div>
                  <span className="pl">8</span>
                  <span className="pl">4</span>
                </div>
                <div>
                  <span className="pl">Edit</span>
                  <span className="pl">Delete</span>
                </div>
              </div>
            </div>
            <div className="border p-3">
              <p className="title">
                Hello i am here to test the headimg amd alsop show collins i am
                not good in front end
              </p>
              <p className="grey">Published: 18 may</p>
              <div className="dflex justify-content-between">
                <div>
                  <span className="pl">8</span>
                  <span className="pl">4</span>
                </div>
                <div>
                  <span className="pl">Edit</span>
                  <span className="pl">Delete</span>
                </div>
              </div>
            </div>
            <div className="border p-3">
              <p className="title">
                Hello i am here to test the headimg amd alsop show collins i am
                not good in front end
              </p>
              <p className="grey">Published: 18 may</p>
              <div className="dflex justify-content-between">
                <div>
                  <span className="pl">8</span>
                  <span className="pl">4</span>
                </div>
                <div>
                  <span className="pl">Edit</span>
                  <span className="pl">Delete</span>
                </div>
              </div>
            </div>
            <div className="border p-3">
              <p className="title">
                Hello i am here to test the headimg amd alsop show collins i am
                not good in front end
              </p>
              <p className="grey">Published: 18 may</p>
              <div className="dflex justify-content-between">
                <div>
                  <span className="pl">8</span>
                  <span className="pl">4</span>
                </div>
                <div>
                  <span className="pl">Edit</span>
                  <span className="pl">Delete</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeleteD;
