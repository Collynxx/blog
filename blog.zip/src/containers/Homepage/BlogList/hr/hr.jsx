import React from "react";
import "./hr.css";

const HomeView = () => {
  return (
    <div className="hr">

    </div>
  );
};

export default HomeView;
