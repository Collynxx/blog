import React, { Component } from "react";
import "./Footer.css";


export class Footer extends Component {
  render() {
    return (
      <div className="footer">
        <p>blog @2022 copyright All rights reserved</p>
      </div>
    );
  }
}

export default Footer;
